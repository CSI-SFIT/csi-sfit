import { useGLTF } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';
import { useMotionValueEvent } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export default function GPUModel({ scrollProgress }) {
    const group = useRef();
    const { scene, animations } = useGLTF('/gpu_model.gltf');

    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        setIsMobile(window.innerWidth <= 768);
    }, []);

    const mixer = useRef();
    const action = useRef();
    const animatedTime = useRef(0);
    const progressRef = useRef(0);

    useEffect(() => {
        if (animations.length) {
            mixer.current = new THREE.AnimationMixer(scene);
            action.current = mixer.current.clipAction(animations[0]);
            action.current.play();
            action.current.paused = true;
        }
    }, [animations, scene]);

    useMotionValueEvent(scrollProgress, 'change', (value) => {
        progressRef.current = value;
    });

    useFrame(() => {
        if (action.current && mixer.current && group.current) {
            const animStart = 0.5;
            const animEnd = 0.95;
            const scroll = progressRef.current;

            const rawT = (scroll - animStart) / (animEnd - animStart);
            const t = THREE.MathUtils.clamp(rawT, 0, 1);

            // Smooth easing for animation and position
            const eased = t < 0.5
                ? 4 * t * t * t
                : 1 - Math.pow(-2 * t + 2, 3) / 2;

            // Animate GPU clip time
            const duration = action.current.getClip().duration;
            const targetTime = eased * duration;
            animatedTime.current = THREE.MathUtils.lerp(animatedTime.current, targetTime, 0.03);
            action.current.time = animatedTime.current;
            mixer.current.update(0);

            // Animate GPU position.z from 0 → 2
            const currentPos = group.current.position;
            const targetZ = THREE.MathUtils.lerp(0, 2, eased);
            currentPos.z = THREE.MathUtils.lerp(currentPos.z, targetZ, 0.1); // dampened motion
        }
    });


    return <primitive object={scene} ref={group} scale={isMobile ? 0.5 : 1.5} />;
}
